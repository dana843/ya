import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:logger/logger.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/feature/view/auth/account_type_screen/account_type_screen.dart';
import 'package:my_crew/feature/view_model/company/company_home_view_model.dart';
import 'package:my_crew/feature/view_model/company/company_job_view_model.dart';
import 'package:my_crew/feature/view_model/search_view_model.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/shared/shared_prefs.dart';
import 'package:my_crew/utils/utils/utils.dart';


class CompanyProfileViewModel extends GetxController {

File? companyLogo ;


  void pickImage({required ImageSource imageSource}) async {
    XFile? pickedImage = await ImagePicker().pickImage(source: imageSource);
    if(pickedImage != null){
      companyLogo = File(pickedImage.path);
    }
    update();
  }


  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  GlobalKey<FormState> basicInfoFormKey = GlobalKey();
  TextEditingController tdFullName = TextEditingController();
  TextEditingController tdEmail = TextEditingController();
  TextEditingController tdPhone = TextEditingController();

  GlobalKey<FormState> bioFormKey = GlobalKey();
  TextEditingController tdBio = TextEditingController();
 

    Future<void> refreshUserData() async {
    await _db.collection(Constants.usersCollection).doc(auth.currentUser?.uid).get().then((data) {
      final uData = UserModel.fromDocumentSnapshot(data);
      SharedPrefs.instance.setUserData(data: uData);
      Utils.instance.hideProgressDialog();
      update();
    }).catchError((e){
      Logger().e(e.toString());
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: e.toString());      
    });
  }

  void fillBasicInfo(){
    final uData = SharedPrefs.instance.getUserData();
    tdFullName.text = uData?.name ?? '';
    tdEmail.text = uData?.email ?? '';
    update();
  }

  void fillBio(){
    tdBio.text =  SharedPrefs.instance.getUserData()?.bio ?? '';
    update();
  }


  Future<void> saveCompanyLogo() async{
    Utils.instance.showProgressDialog();
    final ref = _storage.ref().child('${Constants.usersCollection}/${auth.currentUser!.uid}');
    await ref.putFile(companyLogo!);
    String path =  await ref.getDownloadURL().then((value)=> value);
    _updateImageUrl(url: path);
  }

  void _updateImageUrl({required String url})async{
     auth.currentUser!.updatePhotoURL(url);
     await _db.collection(Constants.usersCollection).doc(auth.currentUser!.uid).update({UserModel.imageUrlKey: url}).then((value) async {
      await auth.currentUser!.updatePhotoURL(url);
      companyLogo = null;
      update();
      Utils.instance.hideProgressDialog();
      Utils.instance.snackSuccess(body: StringKeys.profileUpdatedSuccessfully.tr);
    }).catchError((e) {
      Utils.instance.hideProgressDialog();
      Logger().e(e.toString());
      Utils.instance.snackError(body: StringKeys.errorWhileUpdatingProfie.tr);
    });
  }


  void updateBasicInfo() async {
    if(basicInfoFormKey.currentState!.validate()){
    Get.back();
    Utils.instance.showProgressDialog();
    await _db.collection(Constants.usersCollection).doc(auth.currentUser!.uid).update({
      UserModel.nameKey : tdFullName.text.trim(),
      UserModel.emailKey : tdEmail.text.trim(),
      UserModel.phoneNumberKey : tdPhone.text.trim(),
    }).then((value) async {
       await auth.currentUser?.updateDisplayName(tdFullName.text.trim());
      refreshUserData();
      Get.back();
      Utils.instance.snackSuccess(body: StringKeys.profileUpdatedSuccessfully.tr);
    }).catchError((e){
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: StringKeys.errorWhileUpdatingProfie.tr);
    });
    }
  }

  void updateBio() async {
    if(bioFormKey.currentState!.validate()){
    Get.back();
    Utils.instance.showProgressDialog();
    await _db.collection(Constants.usersCollection).doc(auth.currentUser!.uid).update({
      UserModel.bioKey : tdBio.text.trim(),
    }).then((value) async {
      await refreshUserData();
      Utils.instance.snackSuccess(body: StringKeys.profileUpdatedSuccessfully.tr);
    }).catchError((e){
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: StringKeys.errorWhileUpdatingProfie.tr);
    });
    }
  }


  void logout() async {
    auth.signOut();
    await SharedPrefs.instance.clearUserPrefs();
    await Get.delete<SearchViewModel>(force: true);
    await Get.delete<CompanyJobViewModel>(force: true);
    Get.offAll(()=> const AccountTypeScreen());
    await Get.delete<CompanyHomeViewModel>(force: true);
    await Get.delete<CompanyProfileViewModel>(force: true);
  }
}