import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';

class CompanyJobViewModel extends GetxController {
  final _auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;

  final formKey = GlobalKey<FormState>();
  final tdTitle = TextEditingController();
  final tdJobType = TextEditingController();
  final tdSalary = TextEditingController();
  final tdDescription = TextEditingController();

  String? jobType;

  void changeSelectedJobType({bool partTime = false}){
    jobType = partTime ? 'Part-Time' : 'Full-Time';
    tdJobType.text = jobType!;
    update();
  }

  void addNewJob() async {
    if (formKey.currentState!.validate()) {
      Utils.instance.showProgressDialog();
        final job = JobModel(title: tdTitle.text.trim(), description: tdDescription.text.trim(),
        salary: tdSalary.text.trim(), jobType: tdJobType.text.trim(), companyId: _auth.currentUser!.uid,
        openStatus: true);

        await _db.collection(Constants.jobsCollection).add(job.toJson()).then((value){
          Utils.instance.hideProgressDialog();
          Get.back();
          Utils.instance.snackSuccess(body: StringKeys.jobAddedSuccessfully.tr);
          clearAll();
        }).catchError((e){
          Utils.instance.hideProgressDialog();
          Utils.instance.snackError(body: StringKeys.errorWhileAddingJob.tr);
        });
    }
  }


    void updateJob({required String jobId }) async {
    if (formKey.currentState!.validate()) {
      Utils.instance.showProgressDialog();
        final job = JobModel(title: tdTitle.text.trim(), description: tdDescription.text.trim(),
        salary: tdSalary.text.trim(), jobType: tdJobType.text.trim(), companyId: _auth.currentUser!.uid,
        openStatus: true);

        await _db.collection(Constants.jobsCollection).doc(jobId).update(job.toJson()).then((value){
          Utils.instance.hideProgressDialog();
          Get.back();
          Utils.instance.snackSuccess(body: StringKeys.jobUpdatedSuccessfully.tr);
          clearAll();
        }).catchError((e){
          Utils.instance.hideProgressDialog();
          Utils.instance.snackError(body: StringKeys.errorWhileUpdatingJob.tr);
        });
    }
  }


  void clearAll(){
    tdDescription.clear();
    tdJobType.clear();
    tdSalary.clear();
    tdTitle.clear();
    jobType = null;
  }

  void fillJob({required JobModel job}) {
    tdTitle.text = job.title ?? '';
    tdDescription.text = job.description ?? '';
    tdSalary.text = job.salary ?? '';
    changeSelectedJobType(partTime: job.jobType == 'Part-Time' ? true : false);
  }

}