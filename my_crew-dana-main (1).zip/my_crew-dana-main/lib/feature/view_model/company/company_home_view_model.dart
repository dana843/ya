import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/model/application_model.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';

class CompanyHomeViewModel extends GetxController {
  final auth = FirebaseAuth.instance;
  final _db = FirebaseFirestore.instance;

  Stream<QuerySnapshot<Map<String, dynamic>>> getCompanyJobs(){
    return _db.collection(Constants.jobsCollection).where(JobModel.companyIdKey, isEqualTo : auth.currentUser!.uid).orderBy(JobModel.addedAtKey,descending: true).snapshots();
  }

  void deleteJob({required String jobId}) async {
        await _db.collection(Constants.jobsCollection).doc(jobId).delete().then((value){
          Utils.instance.snackSuccess(body: StringKeys.jobDeletedSuccessfully.tr);
        }).catchError((e){
          Utils.instance.snackError(body: StringKeys.errorWhileDeletingJob.tr);
        });
  }

   List<UserModel> applicants = [];
   List<ApplicationModel> applications = [];

  void getJobApplications({required String? jobId}) async {
    applicants.clear();
    applications.clear();
    Utils.instance.showProgressDialog();
    await _db
        .collection(Constants.jobsCollection)
        .doc(jobId)
        .collection(Constants.applicationsCollection)
        .get()
        .then((apps) async {
      for (QueryDocumentSnapshot<Map<String, dynamic>> a in apps.docs) {
        ApplicationModel app = ApplicationModel.fromDocumentSnapshot(a);
        applications.add(app);
        UserModel applicant = await _getApplicant(applicantId: app.userId);
        applicants.add(applicant);
        update();
      }
      Utils.instance.hideProgressDialog();
    }).catchError((e) {
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: e.toString());
    });
  }

  Future<UserModel> _getApplicant({required String? applicantId}) async {
    return await _db
        .collection(Constants.usersCollection)
        .doc(applicantId)
        .get()
        .then((value) => UserModel.fromDocumentSnapshot(value));
  }

  void _changeApplicationStatus(
      {required ApplicationModel application, required String status}) async {
    Utils.instance.showProgressDialog();
    await _db
        .collection(Constants.usersCollection)
        .doc(application.userId)
        .collection(Constants.appliedJobsCollection)
        .doc(application.id)
        .update({ApplicationModel.statusKey : status})
        .then((value) async {
      await _db.collection(Constants.jobsCollection).doc(application.jobId).collection(Constants.applicationsCollection).doc(application.id).update({
        ApplicationModel.statusKey: status
      }).then((value){
         Utils.instance.hideProgressDialog();
          getJobApplications(jobId: application.jobId);
    }).catchError((e){
          Utils.instance.hideProgressDialog();
        Utils.instance.snackError(body: e.toString());
    });
  }).catchError((e){
        Utils.instance.hideProgressDialog();
        Utils.instance.snackError(body: e.toString());
  });
  }

  void acceptApplication({required ApplicationModel application}){
    _changeApplicationStatus(application: application, status: 'Accepted');
  }

  void rejectApplication({required ApplicationModel application}){
    _changeApplicationStatus(application: application, status: 'Rejected');
  }


}