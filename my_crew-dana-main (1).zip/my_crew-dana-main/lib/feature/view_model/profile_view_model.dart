import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:logger/logger.dart';
import 'package:my_crew/feature/model/application_model.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/feature/view/auth/account_type_screen/account_type_screen.dart';
import 'package:my_crew/feature/view_model/home_view_model.dart';
import 'package:my_crew/feature/view_model/search_view_model.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/shared/shared_prefs.dart';
import 'package:my_crew/utils/utils/utils.dart';

class ProfileViewModel extends GetxController {
  final FirebaseAuth auth = FirebaseAuth.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  GlobalKey<FormState> basicInfoFormKey = GlobalKey();
  TextEditingController tdFullName = TextEditingController();
  TextEditingController tdEmail = TextEditingController();
  TextEditingController tdPhone = TextEditingController();
  bool maleGender = true;

  GlobalKey<FormState> bioFormKey = GlobalKey();
  TextEditingController tdBio = TextEditingController();

  File? profileImage;

  void changeGender() {
    maleGender = !maleGender;
    update();
  }

  void pickImage({required ImageSource imageSource}) async {
    XFile? pickedImage = await ImagePicker().pickImage(source: imageSource);
    if (pickedImage != null) {
      profileImage = File(pickedImage.path);
    }
    update();
  }

  List<JobModel> jobs = [];
  List<ApplicationModel> applications = [];

  void getAppliedJobs() async {
    jobs.clear();
    applications.clear();
    Utils.instance.showProgressDialog();
    await _db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser!.uid)
        .collection(Constants.appliedJobsCollection)
        .get()
        .then((applied) async {
      for (QueryDocumentSnapshot<Map<String, dynamic>> a in applied.docs) {
        ApplicationModel app = ApplicationModel.fromDocumentSnapshot(a);
        applications.add(app);
        JobModel job = await getJob(jobId: app.jobId);
        jobs.add(job);
        update();
      }
      Utils.instance.hideProgressDialog();
    }).catchError((e) {
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: e.toString());
    });
    update();
  }

  Future<JobModel> getJob({required String? jobId}) async {
    return await _db
        .collection(Constants.jobsCollection)
        .doc(jobId)
        .get()
        .then((value) => JobModel.fromDocumentSnapshot(value));
  }

  void cancelApplication(
      {required String? applicationId,
      required String? jobId,
      required int applicationsNumber}) async {
    Utils.instance.showProgressDialog();
    await _db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser?.uid)
        .collection(Constants.appliedJobsCollection)
        .doc(applicationId)
        .delete()
        .then((value) async {
      await _db.collection(Constants.jobsCollection).doc(jobId).update({
        JobModel.applicantsNumberKey: (applicationsNumber - 1)
      }).then((value) async {
        await _db
            .collection(Constants.jobsCollection)
            .doc(jobId)
            .collection(Constants.applicationsCollection)
            .doc(applicationId)
            .delete()
            .then((value) {
          Utils.instance.hideProgressDialog();
          getAppliedJobs();
        });
      }).catchError((e){
        Utils.instance.hideProgressDialog();
        Utils.instance.snackError(body: e.toString());
      });
    }).catchError((e){
          Utils.instance.hideProgressDialog();
        Utils.instance.snackError(body: e.toString());
    });
  }

  Future<void> refreshUserData() async {
    await _db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser?.uid)
        .get()
        .then((data) {
      final uData = UserModel.fromDocumentSnapshot(data);
      SharedPrefs.instance.setUserData(data: uData);
      Utils.instance.hideProgressDialog();
      update();
    }).catchError((e) {
      Logger().e(e.toString());
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: e.toString());
    });
  }

  void fillBasicInfo() {
    final uData = SharedPrefs.instance.getUserData();
    tdFullName.text = uData?.name ?? '';
    tdEmail.text = uData?.email ?? '';
    tdPhone.text = uData?.phoneNumber ?? '';
    maleGender = uData?.gender == 'M' ? true : false;
    update();
  }

  void fillBio() {
    tdBio.text = SharedPrefs.instance.getUserData()?.bio ?? '';
    update();
  }

  Future<void> saveUserAvatar() async {
    Utils.instance.showProgressDialog();
    final ref = _storage
        .ref()
        .child('${Constants.usersCollection}/${auth.currentUser!.uid}');
    await ref.putFile(profileImage!);
    String path = await ref.getDownloadURL().then((value) => value);
    _updateImageUrl(url: path);
  }

  void _updateImageUrl({required String url}) async {
    auth.currentUser!.updatePhotoURL(url);
    await _db
        .collection(Constants.usersCollection)
        .doc(auth.currentUser!.uid)
        .set({UserModel.imageUrlKey: url}, SetOptions(merge: true)).then(
            (value) async {
      await auth.currentUser!.updatePhotoURL(url);
      profileImage = null;
      update();
      Utils.instance.hideProgressDialog();
      Utils.instance
          .snackSuccess(body: StringKeys.profileUpdatedSuccessfully.tr);
    }).catchError((e) {
      Utils.instance.hideProgressDialog();
      Logger().e(e.toString());
      Utils.instance.snackError(body: StringKeys.errorWhileUpdatingProfie.tr);
    });
  }

  void updateBasicInfo() async {
    if (basicInfoFormKey.currentState!.validate()) {
      Get.back();
      Utils.instance.showProgressDialog();
      await _db
          .collection(Constants.usersCollection)
          .doc(auth.currentUser!.uid)
          .update({
        UserModel.nameKey: tdFullName.text.trim(),
        UserModel.emailKey: tdEmail.text.trim(),
        UserModel.phoneNumberKey: tdPhone.text.trim(),
        UserModel.genderKey: maleGender ? 'M' : 'F'
      }).then((value) async {
        await auth.currentUser?.updateDisplayName(tdFullName.text.trim());
        refreshUserData();
        Utils.instance
            .snackSuccess(body: StringKeys.profileUpdatedSuccessfully.tr);
      }).catchError((e) {
        Utils.instance.hideProgressDialog();
        Utils.instance.snackError(body: StringKeys.errorWhileUpdatingProfie.tr);
      });
    }
  }

  void updateBio() async {
    if (bioFormKey.currentState!.validate()) {
      Get.back();
      Utils.instance.showProgressDialog();
      await _db
          .collection(Constants.usersCollection)
          .doc(auth.currentUser!.uid)
          .update({
        UserModel.bioKey: tdBio.text.trim(),
      }).then((value) async {
        await refreshUserData();
        Utils.instance
            .snackSuccess(body: StringKeys.profileUpdatedSuccessfully.tr);
      }).catchError((e) {
        Utils.instance.hideProgressDialog();
        Utils.instance.snackError(body: StringKeys.errorWhileUpdatingProfie.tr);
      });
    }
  }

  void logout() async {
    auth.signOut();
    await SharedPrefs.instance.clearUserPrefs();
    await Get.delete<SearchViewModel>(force: true);
    Get.offAll(() => const AccountTypeScreen());
    await Get.delete<HomeViewModel>(force: true);
    await Get.delete<ProfileViewModel>(force: true);
  }

  void changeTheme({required ThemeMode mode}) {
    SharedPrefs.instance.setTheme(mode: mode);
    Get.changeThemeMode(mode);
    update();
  }
}
