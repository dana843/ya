import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:logger/logger.dart';
import 'package:my_crew/feature/model/application_model.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/feature/view/app/home/favorites_screen/favorites_screen.dart';
import 'package:my_crew/feature/view/app/home/home_screen/home_screen.dart';
import 'package:my_crew/feature/view/app/home/notifications_screen/notifications_screen.dart';
import 'package:my_crew/feature/view/app/home/profile_screen/profile_screen.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';

class HomeViewModel extends GetxController {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  final List<JobModel> favorites = [];

  Stream<QuerySnapshot<Map<String, dynamic>>> getJobs() {
    return _db.collection(Constants.jobsCollection).limit(3).snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> getAllJobs() {
    return _db.collection(Constants.jobsCollection).snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> getCategories() {
    return _db.collection(Constants.categoriesCollection).snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> getCompanies() {
    return _db
        .collection(Constants.usersCollection)
        .where(UserModel.accountTypeKey, isEqualTo: Constants.companyAccount)
        .snapshots();
  }

  void applyJob({required JobModel job}) async {
    Utils.instance.showProgressDialog();
    final application = ApplicationModel(
        userId: _auth.currentUser?.uid, jobId: job.id, status: 'Pending...');
    await _db
        .collection(Constants.usersCollection)
        .doc(_auth.currentUser?.uid)
        .collection(Constants.appliedJobsCollection)
        .add(application.toJson())
        .then((value) async {
          application.id = value.id;
          await _increaseJobApplicants(job: job, application: application);
           })
        .catchError((e) {
      Logger().e(e.toString());
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: StringKeys.errorWhileAppliyingJob.tr);
    });
  }

  Future<void> _increaseJobApplicants(
      {required JobModel job, required ApplicationModel application}) async {
    await _db.collection(Constants.jobsCollection).doc(job.id).update({
      JobModel.applicantsNumberKey: ((job.applicantsNumber ?? 0) + 1)
    }).then((value) async {
      await _storeApplicantData(job: job, application: application);
    }).catchError((e) {
      Logger().e(e, toString());
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: StringKeys.errorWhileAppliyingJob.tr);
    });
  }

  Future<void> _storeApplicantData(
      {required JobModel job, required ApplicationModel application}) async {
    await _db
        .collection(Constants.jobsCollection)
        .doc(job.id)
        .collection(Constants.applicationsCollection)
        .doc(application.id)
        .set(application.toJson())
        .then((value) {
      Utils.instance.hideProgressDialog();
      Utils.instance.snackSuccess(body: StringKeys.appliedSuccessfully.tr);
    }).catchError((e) {
      Logger().e(e, toString());
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: StringKeys.errorWhileAppliyingJob.tr);
    });
  }

  Future<UserModel> getCompanyData({required String companyId}) async {
    Utils.instance.showProgressDialog();
    return await _db
        .collection(Constants.usersCollection)
        .doc(companyId)
        .get()
        .then((value) {
      Utils.instance.hideProgressDialog();
      return UserModel.fromDocumentSnapshot(value);
    }).catchError((e) {
      Logger().e(e.toString());
      Utils.instance.hideProgressDialog();
    });
  }

// Bottom navigation bar
  int bottomNavSelectedIndex = 0;

  void changeBottomNavIndex({required int index}) {
    bottomNavSelectedIndex = index;
    update();
  }

  List<Widget> screens = [
    const HomeScreen(),
    const FavoritesScreen(),
    const NotificationsScreen(),
    const ProfileScreen()
  ];

  Stream<QuerySnapshot<Map<String, dynamic>>> getOpendPositions(
      {required String companyId}) {
    return _db
        .collection(Constants.jobsCollection)
        .where(JobModel.companyIdKey, isEqualTo: companyId)
        .limit(3)
        .snapshots();
  }

  void addToFavorite({required JobModel job}) {
    favorites.add(job);
    update();
    Utils.instance.snackSuccess(body: StringKeys.addedToFavorites.tr);
  }


  void removeFromFavorite({required int index}) {
    favorites.removeAt(index);
    update();
    Utils.instance.snackSuccess(body: StringKeys.removedFromFavorites.tr);
  }


}
