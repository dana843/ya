import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:logger/logger.dart';
import 'package:my_crew/feature/core/theme/asset/asset_manager.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/feature/view/app/company/compay_home_screen/company_home_screen.dart';
import 'package:my_crew/feature/view/app/home/home_placeholder_screen/home_placeholder_screen.dart';
import 'package:my_crew/feature/view/auth/account_type_screen/account_type_screen.dart';
import 'package:my_crew/feature/view/on_boarding/on_boarding_screen.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/shared/shared_prefs.dart';
import 'package:my_crew/utils/utils/utils.dart';


class AuthViewModel extends GetxController {

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  
  // Login screen
  final TextEditingController tdLoginEmail = TextEditingController();
  final TextEditingController tdLoginPassword = TextEditingController();

  // Register screen
  final TextEditingController tdRegisterFullName = TextEditingController();
  final TextEditingController tdRegisterEmail = TextEditingController();
  final TextEditingController tdRegisterPhone = TextEditingController();
  final TextEditingController tdRegisterPassword = TextEditingController();
  final TextEditingController tdRegisterConfirmPassword = TextEditingController();
  final TextEditingController tdRegisterBio = TextEditingController();
  final TextEditingController tdRegisterSpecialization = TextEditingController();
  final TextEditingController tdRegisterSkills = TextEditingController();

  final TextEditingController tdRegisterJobs = TextEditingController();
  final TextEditingController tdRegisterDescriptuin = TextEditingController();
  bool male = true;
  
  // Reset password screen
  final TextEditingController tdResetPasswordEmail = TextEditingController();

  final GlobalKey<FormState> loginFormKey = GlobalKey<FormState>();
  final GlobalKey<FormState> registerFormKey = GlobalKey<FormState>();
  final GlobalKey<FormState> resetPasswordFormKey = GlobalKey<FormState>();

  bool passwordVisibility = false;
  bool confirmPasswordVisibility = false;

  void changePasswordVisibilityState() {
    passwordVisibility = !passwordVisibility;
    update();
    Future.delayed(const Duration(seconds: 2), () {
      passwordVisibility = false;
      update();
    });
  }

  void changeConfirmPasswordVisibilityState() {
    confirmPasswordVisibility = !confirmPasswordVisibility;
    update();
    Future.delayed(const Duration(seconds: 2), () {
      confirmPasswordVisibility = false;
      update();
    });
  }

  void changeGender(){
    male = !male;
    update();
  }


  void login({required int accountType}) async {
    try {
      Utils.instance.showProgressDialog();
      await _auth.signInWithEmailAndPassword(email: tdLoginEmail.text.trim(), password: tdLoginPassword.text.trim()).then((u) => getUserData(userId: u.user!.uid));
    } catch (e) {
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: e is FirebaseAuthException ? e.message ?? '' : e.toString());
    }
  }


  void registerClient() async {
    try {
      Utils.instance.showProgressDialog();
      final UserModel user = UserModel(name: tdRegisterFullName.text.trim(),
       phoneNumber: tdRegisterPhone.text.trim(), email: tdRegisterEmail.text.trim(),
       bio: tdRegisterBio.text.trim(), gender: male ? 'M' : 'F', accountType: Constants.clientAccount,
       specialization: tdRegisterSpecialization.text.trim(), skills: tdRegisterSkills.text.trim());
         await _auth.createUserWithEmailAndPassword(email: user.email!, password: tdRegisterPassword.text.trim()).then((u) async => saveUserData(userId: u.user!.uid, user: user));
    } catch (e) {
      Utils.instance.hideProgressDialog();
      Logger().e(e.toString());
      Utils.instance.snackError(body: e.toString());
    }
  }

  void registerCompany() async {
    try {
      Utils.instance.showProgressDialog();
       final UserModel user = UserModel(name: tdRegisterFullName.text.trim(),
       phoneNumber: tdRegisterPhone.text.trim(), email: tdRegisterEmail.text.trim(),
        bio: tdRegisterDescriptuin.text.trim(), accountType: Constants.companyAccount);
        await _auth.createUserWithEmailAndPassword(email: user.email!, password: tdRegisterPassword.text.trim()).then((u) async => saveUserData(userId: u.user!.uid, user: user));
    } catch (e) {
      Utils.instance.hideProgressDialog();
            Logger().e(e.toString());
      Utils.instance.snackError(body: e.toString());
    }
  }

  Future<void> saveUserData(
      {required String userId, required UserModel user}) async {
        final uJson = user.accountType == Constants.clientAccount ? user.toJsonAsClient() : user.toJsonAsCompany();
        await _db.collection(Constants.usersCollection).doc(userId).set(uJson).then((_) async => {
          await _auth.currentUser!.updateDisplayName(user.name),
          await SharedPrefs.instance.setUserData(data: user),
          Get.offAll(()=> user.accountType == Constants.clientAccount ? const HomePlaceholderScreen() : const CompanyHomeScreen()),
          clearAll()
        }).catchError((e){
          Logger().e(e is FirebaseAuthException ? e.message ?? '' : e.toString());
          Utils.instance.snackError(body: e is FirebaseAuthException ? e.message ?? '' : e.toString());
        });
        Utils.instance.hideProgressDialog();
      }


  Future<void> saveUserDataFromSoicalMediaSignIn(
      {required int accountType, required dynamic user}) async {
              clearAll();
      }


  Future<void> getUserData({required String userId}) async {
    await _db.collection(Constants.usersCollection).doc(userId).get().then((data) {
      final uData = UserModel.fromDocumentSnapshot(data);
      SharedPrefs.instance.setUserData(data: uData);
      Get.offAll(()=> uData.accountType == Constants.clientAccount ? const HomePlaceholderScreen() : const CompanyHomeScreen());
      clearAll();
      Utils.instance.hideProgressDialog();
    }).catchError((e){
      Logger().e(e.toString());
      Utils.instance.hideProgressDialog();
      Utils.instance.snackError(body: e.toString());      
    });
  }


  void loginWithGoogle({required int accountType}) async {
     try {
      GoogleSignInAccount? userAccount = await GoogleSignIn()
          .signIn()
          .catchError((e) => Utils.instance.snackError(body: e.printError));
      if (userAccount == null) return;
      GoogleSignInAuthentication gsia = await userAccount.authentication;
      var credential = GoogleAuthProvider.credential(
          idToken: gsia.idToken, accessToken: gsia.accessToken);
          
      await _auth.signInWithCredential(credential).then((value) async {
        if (value.additionalUserInfo?.isNewUser ?? false) {
          await saveUserDataFromSoicalMediaSignIn(
            user: value.user!,
            accountType: accountType,
          );
        }
        await getUserData(userId: value.user!.uid);
      });
    } on FirebaseAuthException catch (e) {
      Utils.instance.snackError(body: e.message.toString());
      Logger().e(e.message.toString());
    } catch (e) {
      Logger().e(e);
    }
  }

  void sendResetPasswordEmail(){}

  void clearAll() {
    tdLoginEmail.clear();
    tdLoginPassword.clear();
    tdRegisterEmail.clear();
    tdRegisterFullName.clear();
    tdRegisterPassword.clear();
    tdRegisterPhone.clear();
    tdResetPasswordEmail.clear();
  }


  // splash section
    void navigate() {
    Future.delayed(const Duration(milliseconds: 3000), () {
      if (_auth.currentUser != null) {
        getUserData(userId: _auth.currentUser!.uid);
      } else {
        if (!SharedPrefs.instance.isFirstOpen()) {
          Get.off(() => const OnBoardingScreen());
        } else {
          Get.off(() => const AccountTypeScreen());
        }
      }
    });
  }

  // On boarding section
  final PageController pageController = PageController();
  int onBoardingCurrentPage = 0;

  void changeOnBoardingPage({required int pageIndex}) {
    onBoardingCurrentPage = pageIndex;
    update();
  }

  void goToNextPage() {
    pageController.nextPage(
        duration: const Duration(milliseconds: 500), curve: Curves.easeInOut);
    update();
  }

  void goToLastPage() {
    pageController.animateToPage(2,
        curve: Curves.easeInOut, duration: const Duration(milliseconds: 500));
    update();
  }

  // On boarding data
  List<String> titles = [
    StringKeys.onBoardingTitle1.tr,
    StringKeys.onBoardingTitle2.tr,
    StringKeys.onBoardingTitle3.tr
  ];
  List<String> bodys = [
    StringKeys.onBoardingBody1.tr,
    StringKeys.onBoardingBody2.tr,
    StringKeys.onBoardingBody3.tr
  ];
  List<String> images = [AppSvgs.onBoarding1, AppSvgs.onBoarding2, AppSvgs.onBoarding3];
}
