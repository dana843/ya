import 'package:flutter/material.dart';

class NotificationModel {

  NotificationModel({this.title, this.body, this.icon, this.imageUrl, this.time});

  String? id;
  String? title;
  String? body;
  String? time;
  String? imageUrl;
  IconData? icon;
}