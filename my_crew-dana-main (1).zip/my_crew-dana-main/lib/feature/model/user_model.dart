
import 'package:cloud_firestore/cloud_firestore.dart';

class UserModel{

  UserModel({this.name, this.email, this.phoneNumber, this.imageUrl, this.token, this.accountType, this.latitude, this.longitude, this.bio, this.gender, this.id, this.skills, this.specialization});

  String? id;
  String? name;
  String? imageUrl; 
  String? email;
  String? phoneNumber;
  String? token;
  String? gender;
  String? skills;
  String? bio;
  int? accountType;
  double? latitude;
  double? longitude;
  String? specialization;

  static const String idKey = 'id';
  static const String nameKey = 'name';
  static const String emailKey = 'email';
  static const String imageUrlKey = 'image_url';
  static const String phoneNumberKey = 'phone_number';
  static const String accountTypeKey = 'account_type';
  static const String tokenKey = 'token';
  static const String latitudeKey = 'latitude';
  static const String longitudeKey = 'longitude';
  static const String specializationKey = 'specialization';
  static const String bioKey = 'bio';
  static const String skillsKey = 'skills';
  static const String genderKey = 'gender';
  

  Map<String, dynamic> toJson({bool local = false}){
    return {
      if(local)...{
          idKey : id,
      },
    nameKey : name,
    imageUrlKey :imageUrl,
    emailKey :email,
    phoneNumberKey : phoneNumber,
    tokenKey : token,
    accountTypeKey : accountType,
    latitudeKey : latitude,
    longitudeKey : longitude,
    bioKey : bio,
    specializationKey : specialization,
    skillsKey : skills,
    genderKey : gender
    };
  }

  Map<String, dynamic> toJsonAsClient({bool local = false}){
    return {
    nameKey : name,
    emailKey :email,
    phoneNumberKey : phoneNumber,
    accountTypeKey : accountType,
    latitudeKey : latitude,
    longitudeKey : longitude,
    bioKey : bio,
    specializationKey : specialization,
    skillsKey : skills,
    genderKey : gender
    };
  }

  Map<String, dynamic> toJsonAsCompany({bool local = false}){
    return {
    nameKey : name,
    emailKey :email,
    phoneNumberKey : phoneNumber,
    accountTypeKey : accountType,
    latitudeKey : latitude,
    longitudeKey : longitude,
    bioKey : bio
    };
  }

  UserModel.fromJson(Map<String, dynamic> json){
    id = json[idKey];
    name = json[nameKey];
    imageUrl = json[imageUrlKey];
    phoneNumber = json[phoneNumberKey];
    email = json[emailKey];
    token = json[tokenKey];
    accountType = json[accountTypeKey] ?? 0;
    latitude = json[latitudeKey];
    longitude = json[longitudeKey];
    bio = json[bioKey];
    skills = json[skillsKey];
    gender = json[genderKey];
    specialization = json[specializationKey];
  }

    UserModel.fromDocumentSnapshot(DocumentSnapshot<Map<String, dynamic>> snapshot){
    id = snapshot.id;
    name = snapshot.data()?[nameKey];
    imageUrl = snapshot.data()?[imageUrlKey];
    phoneNumber = snapshot.data()?[phoneNumberKey];
    email = snapshot.data()?[emailKey];
    token = snapshot.data()?[tokenKey];
    accountType = snapshot.data()?[accountTypeKey] ?? 0;
    latitude = snapshot.data()?[latitudeKey];
    longitude = snapshot.data()?[longitudeKey];
    bio = snapshot.data()?[bioKey];
    skills = snapshot.data()?[skillsKey];
    gender = snapshot.data()?[genderKey];
    specialization = snapshot.data()?[specializationKey];
    }



}