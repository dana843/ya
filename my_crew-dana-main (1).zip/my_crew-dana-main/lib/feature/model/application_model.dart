
import 'package:cloud_firestore/cloud_firestore.dart';

class ApplicationModel{
  String? id;
  String? userId;
  String? jobId;
  Timestamp? appliedAt;
  String? status;

  static const idKey = "id";
  static const userIdKey = "user_id";
  static const jobIdKey = "job_id";
  static const appliedAtKey = "applied_at";
  static const statusKey = "status";

  ApplicationModel({this.appliedAt, this.jobId, this.status, this.userId});

  Map<String, dynamic> toJson(){
    return {
      userIdKey : userId,
      jobIdKey : jobId,
      appliedAtKey : Timestamp.now().toDate(),
      statusKey : status
    };
  }

  ApplicationModel.fromJson(Map<String,dynamic> json){
    jobId = json[jobIdKey];
    userId = json[userIdKey];
    appliedAt = json[appliedAtKey];
    status = json[status];
  }

  ApplicationModel.fromDocumentSnapshot(DocumentSnapshot<Map<String, dynamic>> snapshot){
    id = snapshot.id;
    jobId = snapshot.data()?[jobIdKey];
    userId = snapshot.data()?[userIdKey];
    appliedAt = snapshot.data()?[appliedAtKey];
    status = snapshot.data()?[statusKey];
  }
}