

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/color/color_manager.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/application_model.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/view/app/home/job_details_screen/job_details_screen.dart';
import 'package:my_crew/feature/view_model/profile_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';

class AppliedJobItem extends StatelessWidget {
  const AppliedJobItem({super.key, required this.job, required this.application});
  final JobModel job;
  final ApplicationModel application;
  
@override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: BorderRadius.circular(SizeManager.r12),
        color: Theme.of(context).backgroundColor,
      child: InkWell(
        onTap: (){
          Get.to(()=> JobDetailsScreen(job: job,));
        },
        borderRadius: BorderRadius.circular(SizeManager.r12),
      child: Container(
        padding: EdgeInsets.only(left: SizeManager.w16, right: SizeManager.w16, bottom: SizeManager.h16,),
        child: Column(
          children: [
            ListTile(
              title: Text(job.title ?? '', style: Theme.of(context).textTheme.headline5?.copyWith(fontWeight: FontWeight.bold),),
              subtitle: Text(job.salary ?? '', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.w500),),
              trailing: Icon(Icons.bookmark_outline_rounded, color: ColorManager.instance.colorPrimary,),
              contentPadding: EdgeInsets.zero,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.access_time, size: SizeManager.r16, color: Theme.of(context).textTheme.bodyText1?.color,),
                    SizedBox(width: SizeManager.w4,),
                    Text(Utils.instance.getDateFormatted(dateTime: job.addedAt?.toDate()), style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.w500,),),
                  ],
                ),
                Text(job.jobType ?? '', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.w500,),),
                Text( application.status ?? '', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontWeight: FontWeight.bold, color : application.status != 'Rejected' ? ColorManager.instance.success : ColorManager.instance.error),),
                if(application.status == 'Pending...')... [ SizedBox(
                  width: SizeManager.w68,
                  height: SizeManager.h36,
                  child: GetBuilder<ProfileViewModel>(
                    builder: (_) {
                      return ElevatedButton(
                          onPressed: () {
                            _.cancelApplication(applicationId: application.id, jobId: job.id, applicationsNumber: job.applicantsNumber ?? 0);
                          },
                          style: ElevatedButton.styleFrom(
                            padding: EdgeInsets.symmetric(horizontal: SizeManager.w8,),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(SizeManager.r12))
                          ),
                          child: Text(StringKeys.cancel.tr),
                          );
                    }
                  ),
                ),]
              ],
            )
          ],
        ),
      ),
    ));
  }
}