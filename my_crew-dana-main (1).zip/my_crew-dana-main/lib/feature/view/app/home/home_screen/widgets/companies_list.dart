import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/feature/view/app/home/companies_screen/companies_screen.dart';
import 'package:my_crew/feature/view/app/home/companies_screen/widgets/company_item.dart';
import 'package:my_crew/feature/view/app/widgets/empty_message.dart';
import 'package:my_crew/feature/view/app/widgets/list_label.dart';
import 'package:my_crew/feature/view/app/widgets/loading.dart';
import 'package:my_crew/feature/view_model/home_view_model.dart';
import '../../../../../../utils/localization/string_keys.dart';

class CompaniesList extends StatelessWidget {
  const CompaniesList({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
         Padding(
            padding: EdgeInsets.symmetric(horizontal: SizeManager.w12),
            child: ListLabel(label: StringKeys.companies.tr, onPressed: (){
              Get.to(()=> const CompaniesScreen());
            }),
          ),
          SizedBox(height: SizeManager.h4,),
           GetBuilder<HomeViewModel>(
             builder: (_) {
               return SizedBox(
                height: Get.width * 0.3,
                 child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
                   stream: _.getCompanies(),
                   builder: (context, snapshot) {
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return const Loading();
                    }else if(snapshot.hasData && snapshot.data!.docs.isNotEmpty){
                      return ListView.separated(
                            padding: EdgeInsets.symmetric(horizontal: SizeManager.w12),
                      scrollDirection: Axis.horizontal,
                      physics: const BouncingScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: snapshot.data!.docs.length,
                      itemBuilder: (context, index) => CompanyItem(company: UserModel.fromDocumentSnapshot(snapshot.data!.docs[index]),),
                           separatorBuilder: (context, index) => SizedBox(width: SizeManager.w8,),
                     );
                    }
                    return EmptyMessage(message: StringKeys.noCampainesFound.tr, withoutImage: true,);
                   }
                 ),
               );
             }
           ),
      ],
    );
  }
}

