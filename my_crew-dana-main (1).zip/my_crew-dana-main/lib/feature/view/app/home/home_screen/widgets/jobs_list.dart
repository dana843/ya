import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/view/app/home/home_screen/widgets/job_item.dart';
import 'package:my_crew/feature/view/app/home/jobs_screen/jobs_screen.dart';
import 'package:my_crew/feature/view/app/widgets/empty_message.dart';
import 'package:my_crew/feature/view/app/widgets/list_label.dart';
import 'package:my_crew/feature/view/app/widgets/loading.dart';
import 'package:my_crew/feature/view_model/home_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';

class JobsList extends StatelessWidget {
  const JobsList({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeViewModel>(
      builder: (_) {
        return Column(children: [
           Padding(
            padding: EdgeInsets.symmetric(horizontal: SizeManager.w12),
            child: ListLabel(label: StringKeys.jobsCapital.tr, onPressed: (){
              Get.to(()=> const JobsScreen());
            }),
          ),
          SizedBox(height: SizeManager.h4,),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                stream: _.getJobs(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Loading();
                  }else if (snapshot.hasData && snapshot.data!.docs.isNotEmpty){
                   return ListView.separated(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), padding: EdgeInsets.symmetric(vertical: SizeManager.h12, horizontal: SizeManager.w12),
                    itemCount: snapshot.data!.docs.length, itemBuilder: (context, index) => JobItem(job: JobModel.fromDocumentSnapshot(snapshot.data!.docs[index]),), separatorBuilder: (context, index) => SizedBox(height: SizeManager.h12));
                  }
                  return EmptyMessage(message: StringKeys.noJobsFound.tr);
                }
              ),
        ],);
      }
    );
  }
}
