import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/core/theme/text_theme/font_size_manager.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/feature/view/app/home/company_screen/company_screen.dart';
import 'package:my_crew/feature/view/app/home/job_details_screen/widgets/dot_container.dart';
import 'package:my_crew/feature/view/app/home/job_details_screen/widgets/job_description_point.dart';
import 'package:my_crew/feature/view/app/home/job_details_screen/widgets/job_details_item.dart';
import 'package:my_crew/feature/view/app/widgets/app_image_network.dart';
import 'package:my_crew/feature/view/widgets/app_back_button.dart';
import 'package:my_crew/feature/view_model/home_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';

class JobDetailsScreen extends StatelessWidget {
  const JobDetailsScreen({super.key, required this.job});

  final JobModel job;
  @override
  Widget build(BuildContext context) {
     UserModel? company;
    return Scaffold(
      appBar: AppBar(
        leading: const AppBackButton(),
        actions: [
          IconButton(onPressed: (){}, icon: Icon(Icons.bookmark_outline_rounded, color: Theme.of(context).textTheme.headline1?.color,))
        ],
      ),
      body: GetBuilder<HomeViewModel>(
        initState: (_){
          WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
           company = await _.controller?.getCompanyData(companyId: job.companyId ?? '');
           _.controller?.update();
           });
        },
        builder: (_) {
          return Column(
            children: [
              Expanded(
                child: ListView(
                  padding: EdgeInsets.symmetric(
                      horizontal: SizeManager.w12, vertical: SizeManager.h16),
                  shrinkWrap: true,
                  children: [
                    Container(
                      padding: EdgeInsets.symmetric(
                          horizontal: SizeManager.w16,
                          vertical: SizeManager.h16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(SizeManager.r12),
                      ),
                      child: Column(
                        children: [
                          AppImageNetwork(
                            width: SizeManager.w60,
                            height: SizeManager.h60,
                            shape: BoxShape.circle,
                          ),
                          SizedBox(
                            height: SizeManager.h12,
                          ),
                          Text(
                            job.title ?? '',
                            style: Theme.of(context)
                                .textTheme
                                .headline4
                                ?.copyWith(fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: SizeManager.h8,),
                          Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  InkWell(
                                    onTap: (){
                                      Get.to(()=> CompanyScreen(company : company ?? UserModel()));
                                    },
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(vertical: SizeManager.h4),
                                      child: Text(company?.name ?? '', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontSize: FontSizeManager.fontSize14,),),
                                    ),
                                  ),
                                  const DotContainer(),
                                  Text('Palestine', style: Theme.of(context).textTheme.bodyText2?.copyWith(fontSize: FontSizeManager.fontSize14),),
                                  const DotContainer(),
                                  Text(Utils.instance.getDateFormatted(dateTime: job.addedAt?.toDate()), style: Theme.of(context).textTheme.bodyText2?.copyWith(fontSize: FontSizeManager.fontSize14,),),
                                ],
                              ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: SizeManager.h20,
                    ),
                    SizedBox(height: SizeManager.h110,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        JobDetailsItem(color: Colors.yellowAccent, label: StringKeys.salary.tr, value: job.salary ?? '', icon: Icons.monetization_on_outlined),
                        JobDetailsItem(color: Colors.greenAccent, label: StringKeys.jobType.tr, value: job.jobType ?? '', icon: Icons.chair_outlined),
                        JobDetailsItem(color: Colors.purpleAccent, label: StringKeys.position.tr, value: 'Mid-Senior', icon: Icons.timer_outlined),
                      ],
                    ),),
                    Divider(color: Theme.of(context).textTheme.bodyText2?.color?.withOpacity(0.5),),
                    SizedBox(height: SizeManager.h8,),
                    Text(StringKeys.description.tr, style: Theme.of(context).textTheme.headline4?.copyWith(fontWeight: FontWeight.w600),),
                    SizedBox(height: SizeManager.h4,),
                    JobDiscriptionPoint(description: job.description ?? '',),

                   SizedBox(height: SizeManager.h20,),
                  
                  ],
                ),
              ),
              SizedBox(height: SizeManager.h12,),
             GetBuilder<HomeViewModel>(
               builder: (_) {
                 return ElevatedButton(onPressed: (){
                  _.applyJob(job: job);
                 }, style: ElevatedButton.styleFrom(shape: BeveledRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(SizeManager.r16), topRight: Radius.circular(SizeManager.r16)))), child: Text(StringKeys.applyNow.tr),);
               }
             )
            ],
          );
        }
      ),
    );
  }
}