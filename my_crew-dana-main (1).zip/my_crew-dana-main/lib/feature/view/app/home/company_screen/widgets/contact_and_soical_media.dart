import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/user_model.dart';
import 'package:my_crew/feature/view/app/chat/chat_screen/chat_screen.dart';
import 'package:my_crew/feature/view/app/home/company_screen/widgets/contact_item.dart';
import 'package:my_crew/feature/view/app/widgets/list_label.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:url_launcher/url_launcher_string.dart';

class ContactAndSocialMedia extends StatelessWidget {
  const ContactAndSocialMedia({super.key, required this.company});
  final UserModel company;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ListLabel(
          label: StringKeys.contactAndSocialMedia.tr,
          justLabel: true,
        ),
        ListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          padding: EdgeInsets.zero,
          children: [
            ContactItem(
              onPressed: () {
                Get.to(()=> ChatScreen(recpient: company));
              },
              icon: Icon(
                Icons.chat_rounded,
                color: Colors.blue.shade900,
              ),
              title: StringKeys.inAppChat.tr,
              subTitle: company.name ?? '',
            ),
            SizedBox(
              height: SizeManager.h4,
            ),
            ContactItem(
              onPressed: () {
                launchUrlString("tel://${company.phoneNumber}");
              },
              icon: Icon(
                Icons.phone,
                color: Colors.blue.shade900,
              ),
              title: StringKeys.phoneNumber.tr,
              subTitle: company.phoneNumber ?? '',
            ),
            SizedBox(
              height: SizeManager.h4,
            ),
            ContactItem(
              onPressed: () {
                launchUrlString('mailto: ${company.email}');
              },
              icon: Icon(
                Icons.email_outlined,
                color: Colors.blue.shade900,
              ),
              title: StringKeys.email.tr,
              subTitle: company.email ?? '',
            ),
            SizedBox(
              height: SizeManager.h4,
            ),
            ContactItem(
              onPressed: () {
                launchUrlString('https://www.google.com/');
              },
              icon: Icon(
                Icons.language_rounded,
                color: Colors.blue.shade900,
              ),
              title: StringKeys.website.tr,
              subTitle: 'https://www.google.com/',
            ),
            SizedBox(
              height: SizeManager.h4,
            ),
            ContactItem(
              onPressed: () {
                launchUrlString('https://www.facebook.com');
              },
              icon: Icon(
                Icons.facebook_rounded,
                color: Colors.blue.shade900,
              ),
              title: StringKeys.facebook.tr,
              subTitle: company.name ?? '',
            ),
            SizedBox(
              height: SizeManager.h4,
            ),
            ContactItem(
              onPressed: () {
                launchUrlString('https://accounts.snapchat.com/accounts/login');
              },
              icon: Icon(
                Icons.snapchat_rounded,
                color: Colors.blue.shade900,
              ),
              title: StringKeys.snapchat.tr,
              subTitle: company.name?.toLowerCase() ?? '',
            ),
            SizedBox(
              height: SizeManager.h4,
            ),
            ContactItem(
              onPressed: () {},
              icon: Icon(
                Icons.location_on,
                color: Colors.blue.shade900,
              ),
              title: StringKeys.address.tr,
              subTitle: 'Palestine Nablus',
            ),
          ],
        ),
      ],
    );
  }
}
