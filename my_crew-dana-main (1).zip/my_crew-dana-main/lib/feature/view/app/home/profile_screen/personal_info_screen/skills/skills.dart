import 'package:flutter/cupertino.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/view/app/home/profile_screen/personal_info_screen/skills/widgets/skill_item.dart';

class Skills extends StatelessWidget {
  const Skills({super.key, required this.skills});

  final String skills;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      runSpacing: SizeManager.h8,
      spacing: SizeManager.h8,
      children: skills.split(',').map((e) => SkillItem(label: e,)).toList(),
      //  List.generate(12, (index) => const SkillItem()),
    );
  }
}