import 'package:flutter/material.dart';
import 'package:flutter_webview_plugin/flutter_webview_plugin.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/color/color_manager.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/shared/shared_prefs.dart';


class Resume extends StatelessWidget {
  const Resume({super.key, required this.resumeLink});

  final String resumeLink;

  @override
  Widget build(BuildContext context) {
    final uName = SharedPrefs.instance.getUserData()?.name ?? '';
    return InkWell(
      onTap: (){
        Get.to(WebviewScaffold(url: resumeLink, appBar: AppBar(leading: IconButton(onPressed: ()=> Get.back(), icon: Icon(Icons.close, color: Theme.of(context).textTheme.headline1?.color,)),), displayZoomControls: true, withZoom: true,));
      },
      child: Row(children: [
        Container(
          alignment: Alignment.center,
          width: SizeManager.w44,
          height: SizeManager.h44,
          decoration: BoxDecoration(
            color: ColorManager.instance.colorPrimary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(SizeManager.r8),
          ),
          child: Icon(Icons.file_present_rounded, color: ColorManager.instance.colorPrimary, size: SizeManager.w40,),
        ),
        SizedBox(width: SizeManager.w20,),
        Text("${uName.substring(0, uName.indexOf(' '))}'s ${StringKeys.resume.tr}", style: Theme.of(context).textTheme.headline5?.copyWith(fontWeight: FontWeight.w500),)
      ],),
    );
  }
}