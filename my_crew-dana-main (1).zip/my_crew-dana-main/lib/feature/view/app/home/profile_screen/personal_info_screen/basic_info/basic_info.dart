import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/view/app/home/profile_screen/personal_info_screen/basic_info/widgets/basic_info_item.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/shared/shared_prefs.dart';


class BasicInfo extends StatelessWidget {
  const BasicInfo({super.key});

  @override
  Widget build(BuildContext context) {
    final userData = SharedPrefs.instance.getUserData();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BasicInfoItem(label: StringKeys.name.tr, value: userData?.name ?? '',),
        BasicInfoItem(label: StringKeys.email.tr, value: userData?.email ?? '',),
        BasicInfoItem(label: StringKeys.phoneNumber.tr, value: userData?.phoneNumber ?? '',),
        BasicInfoItem(label: StringKeys.gender.tr, value: userData?.gender == 'M' ? 'Male' : 'Female',),
      ],
    );
  }
}