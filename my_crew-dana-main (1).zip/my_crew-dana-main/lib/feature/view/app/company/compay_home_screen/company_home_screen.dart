import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/view/app/chat/my_chats_screen/my_chats_screen.dart';
import 'package:my_crew/feature/view/app/company/add_job_screen/add_job_screen.dart';
import 'package:my_crew/feature/view/app/company/company_profile_screen/company_profile_screen.dart';
import 'package:my_crew/feature/view/app/company/compay_home_screen/widgets/company_job_item.dart';
import 'package:my_crew/feature/view/app/home/notifications_screen/notifications_screen.dart';
import 'package:my_crew/feature/view/app/widgets/empty_message.dart';
import 'package:my_crew/feature/view/app/widgets/loading.dart';
import 'package:my_crew/feature/view_model/company/company_home_view_model.dart';
import 'package:my_crew/utils/constants/constants.dart';
import 'package:my_crew/utils/localization/string_keys.dart';

class CompanyHomeScreen extends StatelessWidget {
  const CompanyHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: SizeManager.w40,
        leading:  Padding(
          padding: EdgeInsetsDirectional.only(start: SizeManager.w8),
          child: InkWell(
              onTap: () {
                Get.to(() => const CompanyProfileScreen());
              },
              child: GetBuilder<CompanyHomeViewModel>(
                builder: (_) {
                  return CircleAvatar(
                    radius: SizeManager.r16,
                    backgroundImage: CachedNetworkImageProvider(
                         _.auth.currentUser?.photoURL ?? Constants.urlUserPlacholder),
                  );
                }
              )),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Get.to(() => const MyChatsScreen());
            },
            icon: const Icon(
              Icons.chat_rounded,
            ),
            color: Theme.of(context).textTheme.headline1?.color,
          ),
          IconButton(
            onPressed: () {
              Get.to(() => const NotificationsScreen());
            },
            icon: const Icon(
              Icons.notifications_rounded,
            ),
            color: Theme.of(context).textTheme.headline1?.color,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(onPressed: (){
        Get.to(()=> const AddJobScreen());
      }, label: Text(StringKeys.addNewJob.tr), icon: const Icon(Icons.add_rounded)),
      body:
      GetBuilder<CompanyHomeViewModel>(
        initState: (_){
               if (!Get.isRegistered<CompanyHomeViewModel>()) {
                    Get.put(CompanyHomeViewModel(),);
                  }
        },
        builder: (_) {
          return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _.getCompanyJobs(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Loading();
              }else if (snapshot.hasData && snapshot.data!.docs.isNotEmpty){
               return ListView.separated(padding: EdgeInsets.symmetric(vertical: SizeManager.h12, horizontal: SizeManager.w12),
                itemCount: snapshot.data!.docs.length,
                 itemBuilder: (context, index) => CompanyJobItem(job: JobModel.fromDocumentSnapshot(snapshot.data!.docs[index]),),
                  separatorBuilder: (context, index) => SizedBox(height: SizeManager.h12));
              }
              return EmptyMessage(message: StringKeys.youDontHaveAnyJobs.tr);
            }
          );
        }
      ),
    );
  }
}
