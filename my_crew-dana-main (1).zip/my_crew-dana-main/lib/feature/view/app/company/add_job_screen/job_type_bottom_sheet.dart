import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/color/color_manager.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/view_model/company/company_job_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';


class JobTypeBottomSheet extends StatelessWidget {
  const JobTypeBottomSheet({ 
    Key? key,}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Utils.instance.screenUtil(context: context);
    return  GetBuilder<CompanyJobViewModel>(
      builder: (_) {
        return Container(
              padding: EdgeInsets.only(
                top: SizeManager.h8,
              ),
              decoration: BoxDecoration(
                  color: Theme.of(context).scaffoldBackgroundColor,
                  borderRadius:
                      BorderRadius.vertical(top: Radius.circular(SizeManager.r24))),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: SizeManager.w80,
                  height: SizeManager.h4,
                  decoration: BoxDecoration(
                      color: Theme.of(context).textTheme.bodyText1?.color,
                      borderRadius: BorderRadius.circular(SizeManager.r4)),
                ),
                SizedBox(
                  height: SizeManager.h40,
                  width: Get.width,
                ),
                InkWell(
                    onTap: () {
                       _.changeSelectedJobType(partTime: true);
                    Get.back();},
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: SizeManager.h20),
                      child: Text(
                        StringKeys.partTime.tr,
                        style: Theme.of(context)
                            .textTheme
                            .headline5
                            ?.copyWith(fontWeight: FontWeight.w600),
                      ),
                    )),
                InkWell(
                    onTap:(){ 
                      _.changeSelectedJobType();
                      Get.back();
                      },
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: SizeManager.h20),
                      child: Text(StringKeys.fullTime.tr,
                          style: Theme.of(context)
                              .textTheme
                              .headline5
                              ?.copyWith(fontWeight: FontWeight.w600)),
                    )),
                SizedBox(
                  height: SizeManager.h20,
                ),
                Container(
                  width: Get.width,
                  height: SizeManager.h60,
                  alignment: Alignment.center,
                  color: ColorManager.instance.colorPrimary,
                  child: Text(StringKeys.chooseImageFrom.tr,
                      style: Theme.of(context)
                          .textTheme
                          .headline5
                          ?.copyWith(fontWeight: FontWeight.w500, color: ColorManager.instance.textColorDark)),
                )
              ]),
        );
      }
    );
  }
}
