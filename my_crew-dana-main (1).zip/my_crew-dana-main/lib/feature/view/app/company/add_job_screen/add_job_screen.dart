import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/model/job_model.dart';
import 'package:my_crew/feature/view/app/company/add_job_screen/job_type_bottom_sheet.dart';
import 'package:my_crew/feature/view/widgets/app_back_button.dart';
import 'package:my_crew/feature/view/widgets/app_text_form_filed.dart';
import 'package:my_crew/feature/view_model/company/company_job_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';

class AddJobScreen extends StatelessWidget {
  const AddJobScreen({super.key, this.isUpdate = false, this.job});

  final bool isUpdate;
  final JobModel? job;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(leading: const AppBackButton(), title: Text(isUpdate ? StringKeys.editJob.tr : StringKeys.addNewJob.tr),),
      body: GetBuilder<CompanyJobViewModel>(
        initState: (_){
          if (!Get.isRegistered<CompanyJobViewModel>()) {
            Get.put(CompanyJobViewModel(),permanent: true);
          }
          WidgetsBinding.instance.addPostFrameCallback((timeStamp) { 
               if (isUpdate) {
            _.controller?.fillJob(job : job!);              
            }else {
              _.controller?.clearAll();
            }
          });
        },
        builder: (_) {
          return Form(
            key: _.formKey,
            child: ListView(
              padding: EdgeInsets.symmetric(horizontal: SizeManager.w12, vertical: SizeManager.h20),
              children: [
                AppTextFormFiled(controller: _.tdTitle, label: StringKeys.jobTitle.tr),
                SizedBox(height: SizeManager.h16,),
                Row(
                  children: [
                Expanded(flex: 3, child: AppTextFormFiled(controller: _.tdJobType, label: StringKeys.jobType.tr,readOnly: true, onTap: ()=> Get.bottomSheet(const JobTypeBottomSheet(), isScrollControlled: true),)),
                SizedBox(width: SizeManager.w16,),
                Expanded(flex: 2, child: AppTextFormFiled(controller: _.tdSalary, label: StringKeys.salary.tr)),
                  ],
                ),
                SizedBox(height: SizeManager.h16,),
                AppTextFormFiled(controller: _.tdDescription, label: StringKeys.jobDescription.tr, maxLines: 4,),
                SizedBox(height: SizeManager.h24,),
                ElevatedButton(onPressed: (){
                  isUpdate ? _.updateJob(jobId: job!.id!) : _.addNewJob();
                }, child: Text(isUpdate ? StringKeys.save.tr : StringKeys.add.tr))
              ],
            ),
          );
        }
      ),
    );
  }
}