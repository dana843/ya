import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_crew/feature/core/theme/size/size_manager.dart';
import 'package:my_crew/feature/view/widgets/app_text_form_filed.dart';
import 'package:my_crew/feature/view_model/company/company_profile_view_model.dart';
import 'package:my_crew/utils/localization/string_keys.dart';
import 'package:my_crew/utils/utils/utils.dart';

class EditAboutCompanyDialog extends StatelessWidget {
  const EditAboutCompanyDialog({super.key});

  @override
  Widget build(BuildContext context) {
    Utils.instance.screenUtil(context: context);
    return Dialog(
      backgroundColor: Theme.of(context).backgroundColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: SizeManager.h20, horizontal: SizeManager.w12),
        child: GetBuilder<CompanyProfileViewModel>(
          builder: (_) {
            return Form(
              key: _.bioFormKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,       
                children: [
                  Text(StringKeys.bio.tr, style: Theme.of(context).textTheme.headline4?.copyWith(fontWeight: FontWeight.w500),),
                  SizedBox(height: SizeManager.h20,),
                  AppTextFormFiled(
              controller: _.tdBio,
              label: StringKeys.bio.tr,
              maxLines: 4,
              validator: (e) =>  e.toString().isEmpty
                  ? StringKeys.pleaseEnterBio.tr
                  : null,
            ), 
              SizedBox(height: SizeManager.h16,),
              ElevatedButton(onPressed: (){
                _.updateBio();
              }, child: Text(StringKeys.save.tr))
                  
                ],
              ),
            );
          }
        ),
      ),
    );
  }
}