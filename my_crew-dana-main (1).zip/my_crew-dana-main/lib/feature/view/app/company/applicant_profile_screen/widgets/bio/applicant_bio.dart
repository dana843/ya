import 'package:flutter/material.dart';
import 'package:my_crew/feature/core/theme/text_theme/font_size_manager.dart';

class ApplicantBio extends StatelessWidget {
  const ApplicantBio({super.key, required this.bio});

  final String bio;
  @override
  Widget build(BuildContext context) {
    return Text(bio, style: Theme.of(context).textTheme.bodyText2?.copyWith(fontSize: FontSizeManager.fontSize14), maxLines: 5,);
  }
}